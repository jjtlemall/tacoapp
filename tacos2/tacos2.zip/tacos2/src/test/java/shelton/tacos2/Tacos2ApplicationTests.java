package shelton.tacos2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tacos2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
